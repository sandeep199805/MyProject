package com.cts.HibernetTables1.model;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy =InheritanceType.TABLE_PER_CLASS)
public class Admin extends Common {
	private String authorizedKey;
 

	public Admin(String authorizedKey) {
	
		this.authorizedKey = authorizedKey;
	}


	public String getAuthorizedKey() {
		return authorizedKey;
	}


	public void setAuthorizedKey(String authorizedKey) {
		this.authorizedKey = authorizedKey;
	}


	public Admin() {
		// TODO Auto-generated constructor stub
	}

}
