package com.cts.HibernetTables1.model;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy =InheritanceType.TABLE_PER_CLASS)
public class Seller extends Common{

private String compName;
private String category;
public Seller(String compName, String category, String brandName) {
	
	this.compName = compName;
	this.category = category;
	this.brandName = brandName;
}
@Override
public String toString() {
	return "Seller [compName=" + compName + ", category=" + category + ", brandName=" + brandName + "]";
}
public String getCompName() {
	return compName;
}
public void setCompName(String compName) {
	this.compName = compName;
}
public String getCategory() {
	return category;
}
public void setCategory(String category) {
	this.category = category;
}
public String getBrandName() {
	return brandName;
}
public void setBrandName(String brandName) {
	this.brandName = brandName;
}
private String brandName;
	public Seller() {
		// TODO Auto-generated constructor stub
	}

}
