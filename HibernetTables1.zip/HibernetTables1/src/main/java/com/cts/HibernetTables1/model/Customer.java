package com.cts.HibernetTables1.model;

import javax.persistence.Entity;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;

@Entity
@Inheritance(strategy =InheritanceType.TABLE_PER_CLASS)
public class Customer extends Common {
	private String prodName;
	private String paymentmode;
	
	public Customer(String prodName, String paymentmode) {
		this.prodName = prodName;
		this.paymentmode = paymentmode;
	}


	@Override
	public String toString() {
		return "Customer [prodName=" + prodName + ", paymentmode=" + paymentmode + "]";
	}


	public String getProdName() {
		return prodName;
	}


	public void setProdName(String prodName) {
		this.prodName = prodName;
	}


	public String getPaymentmode() {
		return paymentmode;
	}


	public void setPaymentmode(String paymentmode) {
		this.paymentmode = paymentmode;
	}


	

	public Customer() {
		// TODO Auto-generated constructor stub
	}

}
