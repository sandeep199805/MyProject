package com.cts.HibernetDemo.Test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.cts.HibernetDemo.model.Employee;

public class HibernateExe {

	public static void main(String[] args)
	{
		
		Configuration configuration=new Configuration().configure();
    	SessionFactory sf=configuration.buildSessionFactory();
    	Session session=sf.openSession();
       	session.beginTransaction();
       	Employee emp=new Employee(1001,"Sandeep","Programmer1","Perungudi");
    	Employee emp1=new Employee(1002,"kiriti","Programmer2","Siriseri");
    	Employee emp2=new Employee(1003,"Sunil","Programmer3","Tidel");
    	Employee emp3=new Employee(1004,"Gopi","Programmer4","Asv");
    	Employee emp4=new Employee(1005,"chichu","Programmer5","Mepz");
       	session.save(emp);
       	session.save(emp1);
    	session.save(emp2);
    	session.save(emp3);
    	session.save(emp4);
       	System.out.println(emp);
       	System.out.println(emp1);
       	System.out.println(emp2);
       	System.out.println(emp3);
       	System.out.println(emp4);
       	Employee e=(Employee)session.get(Employee.class,1004);
       	emp1.setBranch("Banglore");
       	session.getTransaction().commit();
       	System.out.println(e);
       	session.close();
	}

}
