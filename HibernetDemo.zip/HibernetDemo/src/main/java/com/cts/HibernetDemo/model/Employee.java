package com.cts.HibernetDemo.model;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Employee implements Serializable {
	@Id
	private int empId;
	@Column(name="employeeName")
	private String empName;
	private String position;
	private String branch;
	
	

	public int getEmpId() {
		return empId;
	}



	public void setEmpId(int empId) {
		this.empId = empId;
	}



	public String getEmpName() {
		return empName;
	}



	public void setEmpName(String empName) {
		this.empName = empName;
	}



	public String getPosition() {
		return position;
	}



	public void setPosition(String position) {
		this.position = position;
	}



	public String getBranch() {
		return branch;
	}



	public void setBranch(String branch) {
		this.branch = branch;
	}



	public Employee() {
		System.out.println("Employee Object is Created");
			}
	public Employee(int empId,String empName,String pos,String branch)
	{
		this.empId=empId;
		this.empName=empName;
		this.position=pos;
		this.branch=branch;
	}



	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", position=" + position + ", branch=" + branch
				+ "]";
	}

}
