package com.example.demo;

import java.util.List;

import javax.persistence.*;

@Entity
public class ShoppingCart {
@Id
private int cart_Id;
@OneToMany
private  List<Product> product;
private int quantity;
private float total_price;


public List<Product> getProduct() {
	return product;
}


public void setProduct(List<Product> product) {
	this.product = product;
}


public int getQuantity() {
	return quantity;
}


public void setQuantity(int quantity) {
	this.quantity = quantity;
}


//productId
public ShoppingCart() {
	System.out.println("ShoppingCart Object Has been Created");
}


public ShoppingCart(int cart_Id, int quantity, float total_price) {
	super();
	this.cart_Id = cart_Id;
	this.quantity = quantity;
	this.total_price = total_price;
}


@Override
public String toString() {
	return "ShoppingCart [cart_Id=" + cart_Id + ", quantity=" + quantity + ", total_price=" + total_price + "]";
}


public int getCart_Id() {
	return cart_Id;
}

public void setCart_Id(int cart_Id) {
	this.cart_Id = cart_Id;
}
public int getQuatity() {
	return quantity;
}
public void setQuatity(int quantity) {
	this.quantity = quantity;
}
public float getTotal_price() {
	return total_price;
}
public void setTotal_price(float total_price) {
	this.total_price = total_price;
}

}
